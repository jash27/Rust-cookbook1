// Task : To explain boolean operations in rust
// Author : Vigneshwer
// Version : 1.0
// Date : 3 Dec 2016

fn main(){
	//Setting boolean and character types
	let bool_val: bool = true;
	let x_char: char = 'a';

	// Printing the character
	println!("x char is {}", x_char);
	println!("Bool value is {}", bool_val);
}