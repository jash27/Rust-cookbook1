// Task : To explain assignment operations in rust
// Author : Vigneshwer
// Version : 1.0
// Date : 3 Dec 2016

fn main(){
	let mut sample_var = 10;
	println!("Value of the sample variable is {}",sample_var);
	
	let sample_var = 20;
	println!("New Value of the sample variable is {}",sample_var);
}