// Task : Sample program in rust 
// Author : Vigneshwer
// Version : 1.0
// Date : 3 Dec 2016

fn main() {
    println!("Welcome to Rust Cookbook");
}